def question_1():
    '''
    here you return the answer to the multiple choice question in the handout,
    your answer should be a character a,b,c or d
    for example, if you think option c is the correct answer,
    return 'c'
    '''
    return 'b'
    raise NotImplemented


def question_2():
    '''
    here you return the answer to the multiple choice question in the handout,
    your answer should be a character a,b,c or d
    for example, if you think option c is the correct answer,
    return 'c'
    '''
    return 'a'
    raise NotImplemented


def question_3():
    '''
    here you return the answer to the multiple choice question in the handout,
    your answer should be a character a,b,c or d
    for example, if you think option c is the correct answer,
    return 'c'
    '''
    return 'a'
    raise NotImplemented


def question_4():
    '''
    here you return the answer to the multiple choice question in the handout,
    your answer should be a character a,b,c or d
    for example, if you think option c is the correct answer,
    return 'c'
    '''
    return 'a'
    raise NotImplemented


def question_5():
    '''
    here you return the answer to the multiple choice question in the handout,
    your answer should be a character a,b,c or d
    for example, if you think option c is the correct answer,
    return 'c'
    '''
    return 'c'
    raise NotImplemented